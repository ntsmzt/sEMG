/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../ADS1298_Monitor/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[26];
    char stringdata0[535];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 26), // "on_pushButton_open_clicked"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 17), // "readyReadCallback"
QT_MOC_LITERAL(4, 57, 26), // "on_pushButton_send_clicked"
QT_MOC_LITERAL(5, 84, 27), // "on_pushButton_close_clicked"
QT_MOC_LITERAL(6, 112, 24), // "handleReplotTimerTimeout"
QT_MOC_LITERAL(7, 137, 15), // "handleFreshPort"
QT_MOC_LITERAL(8, 153, 27), // "on_pushButton_fresh_clicked"
QT_MOC_LITERAL(9, 181, 36), // "on_pushButton_squareWaveTest_..."
QT_MOC_LITERAL(10, 218, 31), // "on_pushButton_noiseTest_clicked"
QT_MOC_LITERAL(11, 250, 27), // "on_pushButton_reset_clicked"
QT_MOC_LITERAL(12, 278, 32), // "on_pushButton_beginReadC_clicked"
QT_MOC_LITERAL(13, 311, 31), // "on_pushButton_stopReadC_clicked"
QT_MOC_LITERAL(14, 343, 30), // "on_pushButton_clearLog_clicked"
QT_MOC_LITERAL(15, 374, 32), // "on_pushButton_normalTest_clicked"
QT_MOC_LITERAL(16, 407, 8), // "minValue"
QT_MOC_LITERAL(17, 416, 10), // "beginpoint"
QT_MOC_LITERAL(18, 427, 8), // "endpoint"
QT_MOC_LITERAL(19, 436, 12), // "channelIndex"
QT_MOC_LITERAL(20, 449, 8), // "maxValue"
QT_MOC_LITERAL(21, 458, 27), // "on_ChannelAllButton_clicked"
QT_MOC_LITERAL(22, 486, 21), // "on_savebutton_clicked"
QT_MOC_LITERAL(23, 508, 8), // "saveData"
QT_MOC_LITERAL(24, 517, 8), // "QString&"
QT_MOC_LITERAL(25, 526, 8) // "filename"

    },
    "MainWindow\0on_pushButton_open_clicked\0"
    "\0readyReadCallback\0on_pushButton_send_clicked\0"
    "on_pushButton_close_clicked\0"
    "handleReplotTimerTimeout\0handleFreshPort\0"
    "on_pushButton_fresh_clicked\0"
    "on_pushButton_squareWaveTest_clicked\0"
    "on_pushButton_noiseTest_clicked\0"
    "on_pushButton_reset_clicked\0"
    "on_pushButton_beginReadC_clicked\0"
    "on_pushButton_stopReadC_clicked\0"
    "on_pushButton_clearLog_clicked\0"
    "on_pushButton_normalTest_clicked\0"
    "minValue\0beginpoint\0endpoint\0channelIndex\0"
    "maxValue\0on_ChannelAllButton_clicked\0"
    "on_savebutton_clicked\0saveData\0QString&\0"
    "filename"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  109,    2, 0x08 /* Private */,
       3,    0,  110,    2, 0x08 /* Private */,
       4,    0,  111,    2, 0x08 /* Private */,
       5,    0,  112,    2, 0x08 /* Private */,
       6,    0,  113,    2, 0x08 /* Private */,
       7,    0,  114,    2, 0x08 /* Private */,
       8,    0,  115,    2, 0x08 /* Private */,
       9,    0,  116,    2, 0x08 /* Private */,
      10,    0,  117,    2, 0x08 /* Private */,
      11,    0,  118,    2, 0x08 /* Private */,
      12,    0,  119,    2, 0x08 /* Private */,
      13,    0,  120,    2, 0x08 /* Private */,
      14,    0,  121,    2, 0x08 /* Private */,
      15,    0,  122,    2, 0x08 /* Private */,
      16,    3,  123,    2, 0x08 /* Private */,
      20,    3,  130,    2, 0x08 /* Private */,
      21,    0,  137,    2, 0x08 /* Private */,
      22,    0,  138,    2, 0x08 /* Private */,
      23,    1,  139,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Int,   17,   18,   19,
    QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Int,   17,   18,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Int, 0x80000000 | 24,   25,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_open_clicked(); break;
        case 1: _t->readyReadCallback(); break;
        case 2: _t->on_pushButton_send_clicked(); break;
        case 3: _t->on_pushButton_close_clicked(); break;
        case 4: _t->handleReplotTimerTimeout(); break;
        case 5: _t->handleFreshPort(); break;
        case 6: _t->on_pushButton_fresh_clicked(); break;
        case 7: _t->on_pushButton_squareWaveTest_clicked(); break;
        case 8: _t->on_pushButton_noiseTest_clicked(); break;
        case 9: _t->on_pushButton_reset_clicked(); break;
        case 10: _t->on_pushButton_beginReadC_clicked(); break;
        case 11: _t->on_pushButton_stopReadC_clicked(); break;
        case 12: _t->on_pushButton_clearLog_clicked(); break;
        case 13: _t->on_pushButton_normalTest_clicked(); break;
        case 14: { double _r = _t->minValue((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 15: { double _r = _t->maxValue((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = _r; }  break;
        case 16: _t->on_ChannelAllButton_clicked(); break;
        case 17: _t->on_savebutton_clicked(); break;
        case 18: { int _r = _t->saveData((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 19;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
